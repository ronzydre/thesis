import time

x = 'dre'
y = 'dre'
if x is y:
    print('yes')
else:
    print('no')
# while (time.time() - x) < 5:
#     print('yo')
